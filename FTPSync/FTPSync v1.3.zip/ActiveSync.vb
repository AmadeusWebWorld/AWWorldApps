﻿Imports System.Net
Imports System.IO

Public Enum Names
    LocalFolder
    FtpFolder
    FtpUsername
    FtpPassword
End Enum


Public Class ActiveSync

    'dont care about trailing slashes or / ~ \ mixups.just make sure not to put // or \\
    Dim cred As FtpInfo = FtpInfo.Default

    Const CONFIGFILE As String = "FTPSync.ini"

    Dim ftpCred As New NetworkCredential()

    Const DIRECTORYNOTEXISTSERROR As String = "The remote server returned an error: (550) File unavailable (e.g., file not found, no access)."

    Private Sub ActiveSync_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Files.Items.Clear()

        If File.Exists(CONFIGFILE) Then cred = New FtpInfo(File.ReadAllText(CONFIGFILE))

        ftpCred.UserName = cred.Username

        ChangeServer(True)

    End Sub

#Region " Credentials & Settings (ChangeServer) "

    Private Function GetKey(ByVal key As Names) As String
        GetKey = cred.Value(key)
        Dim cVal As String = GetKey

        'If String.IsNullOrEmpty(cVal) Then
        'dont show a textbox for FTP user / password if the ftp is null
        Dim ftpFor As String = IIf(key = Names.FtpUsername Or key = Names.FtpPassword, " for " + cred.FtpFolder, String.Empty)
        cVal = InputBox(key.ToString + ftpFor, "App Settings", cVal)
        'End If

        If cVal <> GetKey And String.IsNullOrEmpty(cVal) = False Then
            GetKey = cVal
            'cred.Value(key) = 
            'config(Array.IndexOf(configNames, cKey)) = GetKey
            'If File.Exists(CONFIGFILE) Then File.Delete(CONFIGFILE)
            'File.WriteAllText(CONFIGFILE, String.Join("|", config))
        End If
    End Function

    Dim waitState As Integer


    Private Sub ChangeServer(ByVal startup As Boolean)
        'If Directory.Exists(cred.LocalFolder) = False Then
        cred.LocalFolder = GetKey(Names.LocalFolder)
        'End If

        If (cred.LocalFolder = String.Empty) Then
            Return
        End If

        cred.LocalFolder = cred.LocalFolder.Replace("/", "\")
        cred.LocalFolder += IIf(cred.LocalFolder.EndsWith("\"), "", "\")

        If Directory.Exists(cred.LocalFolder) Then

            fsw.Path = cred.LocalFolder

            If startup Then
                fsw.EnableRaisingEvents = True
                fsw.IncludeSubdirectories = True
                fsw.NotifyFilter = IO.NotifyFilters.FileName Or IO.NotifyFilters.LastWrite
                'Or IO.NotifyFilters.Size 'May not always change, makes 2 calls since LastWrite will anyway be raised
                AddHandler fsw.Changed, AddressOf fsw_Changed
                AddHandler fsw.Created, AddressOf fsw_Changed
                'AddHandler fsw.Renamed, AddressOf fsw_Changed
            End If
        End If


        SetMessage("*** FileWatcher Initialised on " + cred.LocalFolder + Now.ToString(" dd MMM yyyy"))


        cred.FtpFolder = GetKey(Names.FtpFolder)
        ftpCred.UserName = GetKey(Names.FtpUsername)

        cred.FtpFolder = cred.FtpFolder.Replace("\", "/")
        cred.FtpFolder += IIf(cred.FtpFolder.EndsWith("/"), "", "/")
        Sync.Enabled = cred.FtpFolder <> ""

        ftpCred.Password = GetKey(Names.FtpPassword)

        SetMessage(String.Format("FTP Credentials Set for '{0}' (User: '{1}' Pass: '{2}')", cred.FtpFolder, ftpCred.UserName, "".PadRight(ftpCred.Password.Length, "*")))
       
    End Sub

#End Region

#Region " Record Changes (fsw handles & setMessage)"

    Private Sub SetMessage(ByVal msg As String, Optional ByVal item As ListViewItem = Nothing)
        msg = String.Format("{0} - {1}", Now.ToString("HH:mm:ss"), msg)
        If item IsNot Nothing Then
            If item.SubItems.Count = 1 Then item.SubItems.Add(msg) Else item.SubItems(1).Text = msg

            Dim size As String = "Not Exists"
            If File.Exists(item.Tag) Then
                Dim fil As New FileInfo(item.Tag)
                Dim kb As Double = fil.Length
                Select Case kb
                    Case Is > 1024 * 1024 * 1024
                        size = Decimalize(kb / 1024 / 1024 / 1024) & " Gb"
                    Case Is > 1024 * 1024
                        size = Decimalize(kb / 1024 / 1024) & " Mb"
                    Case Is > 1024
                        size = Decimalize(kb / 1024) & " Kb"
                    Case Else
                        size = Decimalize(kb) & " b"
                End Select
            End If
            If item.SubItems.Count = 2 Then item.SubItems.Add(size) Else item.SubItems(2).Text = size

            msg = String.Format("{0} - ({1}) - {2}", item.SubItems(1).Text, item.SubItems(0).Text, item.SubItems(2).Text)
        End If
        Log.AppendText(msg + vbCrLf)
        File.AppendAllText("FTP AutoSync Actions.log", Now.ToString("dd MMM yyyy ") + msg + vbCrLf)
    End Sub

    Private Function Decimalize(ByVal val As Double) As String
        val = System.Convert.ToInt64(val * 100) / 100
        Return CStr(val)
    End Function

    Private Sub fsw_Changed(ByVal sender As System.Object, ByVal e As System.IO.FileSystemEventArgs)

        Dim itm() As ListViewItem = Files.Items.Find(e.FullPath, False)

        Dim item As ListViewItem = Nothing
        If e.ChangeType = IO.WatcherChangeTypes.Deleted Then
            'If itm.Length = 1 Then Files.Items.Remove(itm(0)) 'remove since forced to remove nonexistant files anyway
        ElseIf itm.Length = 0 Or e.ChangeType = IO.WatcherChangeTypes.Renamed Then
            item = Files.Items.Add(e.FullPath, e.Name, 0)
            item.Tag = e.FullPath   'key doesnt seem to be accessible on item :(
        ElseIf itm.Length = 1 Then
            item = itm(0)
        End If
        If item IsNot Nothing Then
            SetMessage(e.ChangeType.ToString, item)
            item.Checked = True
        End If

        RemoveNonExistant()

    End Sub

    Private Sub fsw_Renamed(ByVal sender As Object, ByVal e As System.IO.RenamedEventArgs) Handles fsw.Renamed
        Dim itm() As ListViewItem = Files.Items.Find(e.FullPath, False)
        Dim r As IO.RenamedEventArgs = TryCast(e, IO.RenamedEventArgs)
        If r IsNot Nothing Then
            itm = (Files.Items.Find(r.OldFullPath, False))
            If itm.Length = 1 Then Files.Items.Remove(itm(0))
        End If
        Dim f As New FileSystemEventArgs(WatcherChangeTypes.Renamed, e.FullPath, e.Name)
        fsw_Changed(sender, f)
    End Sub

    'since the move action does not seem to raise any event other that create, we must manually delete the old name (if existed).
    Private Sub RemoveNonExistant()
        Dim i As Integer = 0
        Do Until i >= Files.Items.Count
            If IO.File.Exists(cred.LocalFolder + Files.Items(i).Text) Then
                i += 1
            Else
                Files.Items.RemoveAt(i)
            End If
        Loop
    End Sub

#End Region

    'http://www.codeguru.com/csharp/csharp/cs_internet/desktopapplications/article.php/c13163/
    Private Sub UploadDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Sync.Click, DeleteFTP.Click, DeleteLocal.Click
        Dim btnName As String = CType(sender, Button).Name
        Dim delFtp As Boolean = btnName = "DeleteFTP"
        Dim delLocal As Boolean = btnName = "DeleteLocal"
        If btnName.StartsWith("Delete") Then
            btnName = btnName.Replace("Delete", "Delete ")
            If MsgBox("Sure you want to " + btnName, MsgBoxStyle.YesNo, "Confirm " + btnName) = MsgBoxResult.No Then Exit Sub
        End If



        For Each itm As ListViewItem In Files.Items
            If itm.Checked Then
                If delLocal Then

                    Dim msg As String = "Deleting..."
                    Try
                        If File.Exists(itm.Tag) Then
                            File.Delete(itm.Tag)
                        Else
                            msg = "File Delete - Doesnt Exist"
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.Message, "Local File Delete Error")
                        msg = "File Delete Error - " + ex.ToString
                    End Try
                    SetMessage(msg, itm)

                Else
                    SetMessage(SyncFTP(itm.Text, delFtp), itm)
                End If

                If Not delFtp Then itm.Checked = False
                Application.DoEvents()
            End If
        Next
        If delLocal Then RemoveNonExistant()
    End Sub

    Private Function CreateFTPReq(ByVal uri As String, Optional ByVal method As String = Nothing) As FtpWebRequest
        '// Create FtpWebRequest object from the Uri provided
        Dim res As FtpWebRequest = FtpWebRequest.Create(New Uri(uri))

        '// Provide the WebPermission Credentials
        res.Credentials = ftpCred

        '// By default KeepAlive is true, where the control connection is not closed after a command is executed.
        res.KeepAlive = False

        If method <> Nothing Then
            res.Method = method
        End If

        Return res
    End Function

    Private Function SyncFTP(ByVal relPath As String, Optional ByVal delete As Boolean = False) As String
        Dim result As String = "No Action on file: " + relPath

        Dim fileInf As New FileInfo(cred.LocalFolder + relPath)
        Dim uri As String = cred.FtpFolder + relPath.Replace("\", "/")

tryagain:
        Dim reqFTP As FtpWebRequest

        If delete Then
            reqFTP = CreateFTPReq(uri, WebRequestMethods.Ftp.DeleteFile)
            Try
                Dim response As FtpWebResponse = reqFTP.GetResponse()
                result = "Delete Status: " & response.StatusDescription.Replace(vbCrLf, "")
                response.Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message, "Delete Error")
                result = "Delete Error - " + ex.ToString
            End Try
        Else
            '// Specify the command to be executed.
            reqFTP = CreateFTPReq(uri, WebRequestMethods.Ftp.UploadFile)

            '// Specify the data transfer type.
            reqFTP.UseBinary = True

            '// Notify the server about the size of the uploaded file
            reqFTP.ContentLength = fileInf.Length

            '// The buffer size is set to 2kb
            Dim buffLength As Integer = 2048
            Dim buff(buffLength) As Byte
            Dim contentLen As Integer

            Try

                '// Opens a file stream (System.IO.FileStream) to read the file to be uploaded
                Using fs As FileStream = fileInf.OpenRead()

                    '// Stream to which the file to be upload is written
                    Dim strm As Stream = reqFTP.GetRequestStream()

                    '// Read from the file stream 2kb at a time
                    contentLen = fs.Read(buff, 0, buffLength)

                    '// Till Stream content ends
                    While contentLen <> 0
                        '// Write Content from the file stream to the FTP Upload Stream
                        strm.Write(buff, 0, contentLen)
                        contentLen = fs.Read(buff, 0, buffLength)
                        Application.DoEvents()
                    End While

                    '// Close the file stream and the Request Stream
                    strm.Close()
                    fs.Close()
                End Using

                result = "Upload OK"

            Catch ex As Exception
                If ex.Message = DIRECTORYNOTEXISTSERROR Then
                    Dim fol As String = uri.Substring(0, uri.LastIndexOf("/"))
                    CreateFTPFol(fol)
                    SetMessage("Create Folder:" + fol)
                    GoTo tryagain
                Else
                    MessageBox.Show(ex.Message, "Upload Error")
                    result = "Upload Error - " + ex.ToString
                End If
            End Try
        End If
        Return result
    End Function

    Private Sub CreateFTPFol(ByVal fol As String)
        Dim reqFTP As FtpWebRequest = CreateFTPReq(fol, WebRequestMethods.Ftp.MakeDirectory)
        Try
            Using response As FtpWebResponse = CType(reqFTP.GetResponse, FtpWebResponse)
                response.Close()
            End Using
        Catch ex As Exception
            If ex.Message = DIRECTORYNOTEXISTSERROR Then
                CreateFTPFol(fol.Substring(0, fol.LastIndexOf("/")))
                Dim mkdir As FtpWebRequest = CreateFTPReq(fol, WebRequestMethods.Ftp.MakeDirectory)
                Using response As FtpWebResponse = CType(mkdir.GetResponse, FtpWebResponse)
                    response.Close()
                End Using
            Else
                SetMessage("Create Folder Error - " + ex.ToString)
            End If
        End Try
    End Sub

#Region " Column Resizing "

    Private isResizing As Boolean

    Private Sub ActiveSync_Resize(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Resize
        Dim c1 As ColumnHeader = Files.Columns(0)
        Dim c2 As ColumnHeader = Files.Columns(1)
        Dim c3 As ColumnHeader = Files.Columns(2)
        Dim w As Long = Files.Width - 30 - c3.Width, ow As Long = c1.Width + c2.Width
        Dim rat As Double = c1.Width / c2.Width
        isResizing = True
        c1.Width += (w - ow) * rat / (rat + 1)
        c2.Width += (w - ow) * 1 / (rat + 1)

        'InputPanel.Top = (splitter1.Height - InputPanel.Height) / 2
    End Sub

    Private Sub Files_ColumnWidthChanged(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnWidthChangedEventArgs) Handles Files.ColumnWidthChanged
        If e.ColumnIndex = 0 Then
            If isResizing Then
                isResizing = False
            Else
                Files.Columns(1).Width = Files.Width - 30 - Files.Columns(0).Width
            End If
        End If
    End Sub

#End Region

    Private Sub Pause_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Pause.Click
        fsw.EnableRaisingEvents = Not fsw.EnableRaisingEvents
        Pause.Text = IIf(fsw.EnableRaisingEvents, "&Pause", "&Play")
    End Sub

    Private Sub Log_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Log.KeyDown
        If e.Control And e.KeyCode = Keys.A Then Log.SelectAll()
        If e.Control And e.KeyCode = Keys.Insert Then ChangeServer(False)
        If e.Control And e.KeyCode = Keys.Return Then MakeWebRequest()
    End Sub

    Private Sub Files_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles Files.KeyDown
        If e.KeyCode = Keys.F5 Then RemoveNonExistant()
        If e.Control And (e.KeyCode = Keys.A Or e.KeyCode = Keys.U) Then
            Dim checked As Boolean = e.KeyCode = Keys.A
            For Each itm As ListViewItem In Files.Items
                itm.Checked = checked
            Next
        End If
        If e.Control And e.KeyCode = Keys.Delete Then
            For i As Integer = Files.SelectedIndices.Count - 1 To 0 Step -1
                Files.Items.RemoveAt(Files.SelectedIndices(i))
            Next
        End If
    End Sub

    Private Sub Files_DragEnter(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Files.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then e.Effect = DragDropEffects.All
    End Sub

    Private Sub Files_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Files.DragDrop
        For Each fil As String In e.Data.GetData(DataFormats.FileDrop)

            Dim item() As ListViewItem = Files.Items.Find(fil, False)

            If item.Length = 0 Then
                Dim itm = Files.Items.Add(fil, New FileInfo(fil).Name, 0)
                itm.Tag = fil   'key doesnt seem to be accessible on item 

                SetMessage("DragDrop", itm)
                itm.Checked = True
            ElseIf item.Length = 1 Then
                item(0).Checked = True
            End If
        Next
    End Sub

    Private Sub MakeWebRequest()
        Dim req = HttpWebRequest.Create(InputBox("Enter the url to make the request", "Web Request", "http://mini.cselian.com/js/fckeditor/editor/filemanager/browser/default/connectors/php/connector.php?Command=GetFoldersAndFiles&Type=Image&CurrentFolder=%2F"))
        Dim res As HttpWebResponse = req.GetResponse()
        File.WriteAllText("Response.txt", New StreamReader(res.GetResponseStream()).ReadToEnd())
        MessageBox.Show("Response written to : " + New FileInfo("Response.txt").FullName)
    End Sub


End Class