Public Class FtpInfo

    Dim _localFolder As String
    Dim _ftpFolder As String
    Dim _username As String
    Dim _password As String

    Public Shared [Default] As New FtpInfo("D:\web|FTP://ftp.cselian.com//www/|webuser|")

    Public Property Value(ByVal name As Names)
        Get
            Select Case name
                Case Names.FtpFolder
                    Return Me.FtpFolder
                Case Names.FTPPassword
                    Return Me.Password
                Case Names.FTPUsername
                    Return Me.Username
                Case Names.LocalFolder
                    Return Me.LocalFolder
                Case Else
                    Throw New NotSupportedException
            End Select
        End Get
        Set(ByVal value)
            Select Case name
                Case Names.FtpFolder
                    Me.FtpFolder = value
                Case Names.FTPPassword
                    Me.Password = value
                Case Names.FTPUsername
                    Me.Username = value
                Case Names.LocalFolder
                    Me.LocalFolder = value
                Case Else
                    Throw New NotSupportedException
            End Select
        End Set
    End Property

    Public Sub New(ByVal val As String)
        Dim vals = val.Split("|")
        If vals.Length > 0 Then Value(Names.LocalFolder) = vals(0)
        If vals.Length > 1 Then Value(Names.FtpFolder) = vals(1)
        If vals.Length > 2 Then Value(Names.FtpUsername) = vals(2)
        If vals.Length > 3 Then Value(Names.FtpPassword) = vals(3)
    End Sub

    Public Property LocalFolder() As String
        Get
            Return _localFolder
        End Get
        Set(ByVal value As String)
            _localFolder = value
        End Set
    End Property

    Public Property FtpFolder() As String
        Get
            Return _ftpFolder
        End Get
        Set(ByVal value As String)
            _ftpFolder = value
        End Set
    End Property

    Public Property Username() As String
        Get
            Return _username
        End Get
        Set(ByVal value As String)
            _username = value
        End Set
    End Property

    Public Property Password() As String
        Get
            Return _password
        End Get
        Set(ByVal value As String)
            _password = value
        End Set
    End Property



End Class
